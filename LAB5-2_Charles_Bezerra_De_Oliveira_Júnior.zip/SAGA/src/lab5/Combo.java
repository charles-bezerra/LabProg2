package lab5;

import java.text.DecimalFormat;

public class Combo extends Produto {
    private Produto[] produtos;
    private Double fator;

    Combo(String nome, String descricao, Double fator, Produto[] produtos){
        super(nome, descricao, 0.0);
        this.fator = fator;
        this.produtos = produtos;
        this.preco = this.getPreco();
    }

    @Override
    public Double getPreco(){
        Double valor = 0.0;
        for (Produto produto: this.produtos)
            valor += produto.getPreco();
        return valor - (valor*this.fator);
    }

    @Override
    public String toString(){
        DecimalFormat df = new DecimalFormat("###,###,##0.00");
        return this.nome + " - " + this.descricao + " - R$" + df.format( this.preco );
    }
}
