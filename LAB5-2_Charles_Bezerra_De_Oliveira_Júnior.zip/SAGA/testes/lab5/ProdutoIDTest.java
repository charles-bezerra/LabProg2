package lab5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ProdutoIDTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
