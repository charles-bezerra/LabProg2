/**
 * 
 */
package lab5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author charlesboj
 *
 */
class ProdutoControllerTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
